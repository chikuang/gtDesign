# gtDesign: Optimal group testing experimental designs

2026-03-18

<!-- badges: start -->

<!-- [![R-CMD-check](https://github.com/chikuang/cvxDesign/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/chikuang/cvxDesign/actions/workflows/R-CMD-check.yaml) -->

[![](https://img.shields.io/github/languages/code-size/chikuang/cvxDesign.svg)](https://github.com/chikuang/cvxDesign)
<!-- badges: end -->

**Authors:**  
Chi-Kuang Yeh (Georgia State University)  
[![ORCID](https://img.shields.io/badge/ORCID-0000--0001--7057--2096-A6CE39?logo=orcid.png)](https://orcid.org/0000-0001-7057-2096)

Weng Kee Wong (University of California, Los Angeles)  
[![ORCID](https://img.shields.io/badge/ORCID-0000--0001--5568--3054-A6CE39?logo=orcid.png)](https://orcid.org/0000-0001-5568-3054)

Julie Zhou (University of Victoria)

## Description

`gtDesign` is an R package for computing optimal experimental designs
using convex optimization.  
The package is intended for researchers and practitioners working on
approximate and exact design problems under a variety of criteria,
including classical criteria such as D-, A-, E-, and c-optimality, as
well as compound and multi-objective design problems.

The package is motivated by modern design settings where efficient
numerical optimization, equivalence-theorem-based verification, and
flexible model specification are all essential.

## Installation

You can install the development version of `cvxDesign` from GitHub by
running

``` r
# install.packages("pak")
pak::pak("chikuang/cvxDesign")
```

or

``` r
# install.packages("remotes")
remotes::install_github("chikuang/cvxDesign")
```

## Details

Consider a regression model of the form

$$
y_i = \eta(\mathbf{x}_i, \boldsymbol{\theta}) + \varepsilon_i, \quad i = 1, \ldots, n,
$$

where $y_i$ is the response observed at design point
$\mathbf{x}_i \in \mathcal{X}$,  
$\boldsymbol{\theta} \in \mathbb{R}^p$ is an unknown parameter vector,
and $\eta(\mathbf{x}, \boldsymbol{\theta})$ is the mean response
function, which may be linear or nonlinear in the parameters.

Optimal design seeks a design measure $\xi$ over the design space
$\mathcal{X}$ that optimizes a scalar criterion based on the information
matrix $M(\xi)$. Common criteria include:

- **D-optimality**, which maximizes $\log \det M(\xi)$;
- **A-optimality**, which minimizes $\mathrm{tr}\{M^{-1}(\xi)\}$;
- **E-optimality**, which maximizes the minimum eigenvalue of $M(\xi)$;
- **c-optimality**, which minimizes the variance of estimating a
  specified linear combination of parameters.

In many applications, the design problem can be formulated and solved
using convex optimization. This makes it possible to handle a wide range
of criteria and constraints in a unified computational framework.

The goal of `cvxDesign` is to provide a clean and extensible interface
for these computations, together with tools for:

- computing optimal approximate designs,
- studying exact designs on finite candidate sets,
- evaluating design efficiency,
- checking equivalence theorems,
- visualizing directional derivative or sensitivity functions.

## Examples

First load the package.

``` r
# load package
library(cvxDesign)
```

### D-optimal design for a quadratic regression model

Consider the quadratic regression model

$$
y_i = \beta_0 + \beta_1 x_i + \beta_2 x_i^2 + \varepsilon_i.
$$

We first define the regression function.

``` r
quad_reg <- function(x) {
  c(1, x, x^2)
}
```

Suppose the candidate design space is a finite grid on $[-1,1]$.

``` r
u <- seq(-1, 1, length.out = 101)
head(u)
```

    [1] -1.00 -0.98 -0.96 -0.94 -0.92 -0.90

A typical workflow in `cvxDesign` will look like the following.

``` r
dout <- calc_Dopt(
  u = u,
  f = quad_reg,
  drop_tol = 1e-4
)

dout$design |> round(3)
```

      point weight
    1    -1  0.333
    2     0  0.333
    3     1  0.333

``` r
dout$value
```

    [1] -1.909543

``` r
dout$status
```

    [1] "optimal"

The returned object is expected to contain at least:

- the selected support points,
- the corresponding optimal weights,
- the value of the design criterion,
- and, when requested, information useful for equivalence-theorem
  checks.

### A-optimal design

Similarly, one may compute the A-optimal design by changing the
criterion.

``` r
aout <- calc_Aopt(
  u = u,
  f = quad_reg,
  drop_tol = 1e-4
)

aout$design |> round(3)
```

      point weight
    1    -1   0.25
    2     0   0.50
    3     1   0.25

``` r
aout$value
```

    [1] 8

``` r
aout$status
```

    [1] "optimal"

### c-optimal design

If the target is a specific linear combination $c^\top \theta$, then a
c-optimal design can be computed by supplying the vector `cvec`.

``` r
cout <- calc_copt(
  u = u,
  f = quad_reg,
  cVec = c(0.3, 0.4, 0.3),
  drop_tol = 1e-4
)

cout$design |> round(3)
```

      point weight
    1    -1  0.125
    2     1  0.875

``` r
cout$value
```

    [1] 0.16

``` r
cout$status
```

    [1] "optimal"

### Equivalence theorem

An important part of optimal design computation is verification.  
The package is designed to support equivalence-theorem-based diagnostics
and plotting.

``` r
plot_equivalence(
  design = dout$design,
  u = u,
  f = quad_reg,
  criterion = "D"
)
```

``` r
quad_reg <- function(x) c(1, x, x^2)
u <- seq(-1, 1, length.out = 101)

dout <- calc_Dopt(u, quad_reg, drop_tol = 1e-4)
eq_d <- check_equivalence(dout, f = quad_reg)

print(eq_d)
```

    Equivalence theorem check
    Criterion          : D 
    Tolerance          : 1e-06 
    Max violation      : 3.94291e-05 
    All nonpositive    : FALSE 
    Support equal zero : FALSE 

``` r
plot_equivalence(eq_d)
```

![](README_files/figure-commonmark/equivalence-1.png)

``` r
# Aopt
aout <- calc_Aopt(u, quad_reg, drop_tol = 1e-4)
eq_a <- check_equivalence(aout, f = quad_reg)
plot_equivalence(eq_a)
```

![](README_files/figure-commonmark/equivalence-2.png)

``` r
# copt
cout <- calc_copt(u, quad_reg, cVec = c(1, 0.5, 0),
                  drop_tol = 1e-6)
eq_c <- check_equivalence(cout, f = quad_reg)
plot_equivalence(eq_c)
```

![](README_files/figure-commonmark/copt%20equivalence-1.png)

## Planned features

- [x] Basic package infrastructure
- [x] Core support for convex-optimization-based design computation
- [x] D-optimality
- [x] A-optimality
- [ ] E-optimality
- [ ] c-optimality
- [ ] Compound and multi-objective criteria
- [ ] Equivalence theorem (sensitivity functions) diagnostics
- [ ] Exact design support on finite candidate sets
- [ ] Benchmark examples and vignettes
- [ ] Shiny app
- [ ] JSS paper companion materials

## Package vision

The long-term goal of `cvxDesign` is to provide a general computational
framework for modern optimal design problems, including:

- classical regression design,
- heteroscedastic models,
- constrained design problems,
- compound and robust criteria,
- group testing design,
- and other application-driven problems arising in statistics,
  biostatistics, and machine learning.

## References

1.  Atkinson, Anthony C., Donev, Aleksandar N., and Tobias, Randall D.
    (2007). *Optimum Experimental Designs, with SAS*. Oxford University
    Press.
2.  Fedorov, Valerii V. (1972). *Theory of Optimal Experiments*.
    Academic Press.
3.  Pukelsheim, Friedrich. (2006). *Optimal Design of Experiments*.
    SIAM.
4.  Silvey, Samuel D. (1980). *Optimal Design*. Chapman and Hall.
5.  Yeh, Chi-Kuang and collaborators. Ongoing work on
    convex-optimization-based methods for compound and
    application-driven optimal design problems.
